import mysql.connector


class DatabasePedidos:
    def __createCursor(self):
        con = mysql.connector.connect(
            host="localhost", user="root", passwd="12345678B-", database="lacocinadeapolo"
        )
        cursor = con.cursor()
        return con, cursor

    def getAllProd(self,idusuario):
        con, cursor = self.__createCursor()
        cursor.execute(f"SELECT venta.id, detalles_venta.nombre_prod, venta.cantidad FROM venta INNER JOIN detalles_venta ON venta.id=detalles_venta.id_venta and venta.usuarios_id = {idusuario};")
        data = cursor.fetchall()
        print(data, con)
        return data

    def precioEnvio(self,departamento):
        con, cursor = self.__createCursor()
        sql=f"SELECT * FROM lacocinadeapolo.precio_envio where departamento = '{departamento}';"
        cursor.execute(sql)
        data = cursor.fetchone()
        print(data, con)
        return data    
    
    def getAllPedidos(self, idpedido):
        con, cursor = self.__createCursor()
        cursor.execute(f"SELECT * FROM lacocinadeapolo.venta where id={idpedido};")
        data = cursor.fetchall()
        print(data, con)
        return data


